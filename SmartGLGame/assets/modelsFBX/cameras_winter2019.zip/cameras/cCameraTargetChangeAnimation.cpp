#include "cCameraTargetChangeAnimation.h"

cCameraTargetChangeAnimation::cCameraTargetChangeAnimation(
	const glm::mat4& initialTransform,
	const glm::mat4& finalTransform,
	float time)
	: mCurrentTime(0.f)
	, mFullTime(time)
	, mIsComplete(false)
{
	mInterpolatedTransform = glm::inverse(finalTransform) * initialTransform;
}

cCameraTargetChangeAnimation::~cCameraTargetChangeAnimation()
{

}


void cCameraTargetChangeAnimation::Update(float dt)
{
	if (mIsComplete)
	{
		return;
	}
	mCurrentTime += dt;
	if (mCurrentTime >= mFullTime)
	{
		// we're done!
		mIsComplete = true;
		mCurrentTime = mFullTime;
		mCurrentTransform = glm::mat4(1.f);
	}
	else
	{
		float tRatio = mCurrentTime / mFullTime;
		// move towards the identity matrix from the interpolated transform by tRatio
		mCurrentTransform = glm::interpolate(mInterpolatedTransform, glm::mat4(1.f), glm::sqrt(tRatio));
	}
}

void cCameraTargetChangeAnimation::GetCurrentTransform(glm::mat4& currentTransformOut)
{
	currentTransformOut = mCurrentTransform;
}

bool cCameraTargetChangeAnimation::IsComplete()
{
	return mIsComplete;
}
