#pragma once
#include <game_math.h>

class cCameraTargetChangeAnimation
{
public:
	cCameraTargetChangeAnimation(
		const glm::mat4& initialTransform, 
		const glm::mat4& finalTransform, 
		float time);
	~cCameraTargetChangeAnimation();

	void Update(float dt);
	void GetCurrentTransform(glm::mat4& currentTransformOut);
	bool IsComplete();
private:
	float mFullTime;
	float mCurrentTime;
	bool mIsComplete;
	// this is what we travel from, towards the identity matrix
	glm::mat4 mInterpolatedTransform;
	glm::mat4 mCurrentTransform;
};